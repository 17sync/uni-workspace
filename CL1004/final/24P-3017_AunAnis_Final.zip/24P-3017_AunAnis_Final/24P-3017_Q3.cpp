/* Done on paper.
-Muhammad Aun Anis (24P-3017) */